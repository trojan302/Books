<?php

namespace Thelia\Model;

use Thelia\Model\Base\ProfileResource as BaseProfileResource;

class ProfileResource extends BaseProfileResource
{
}
