<?php

namespace Thelia\Model;

use Thelia\Model\Base\OrderProductAttributeCombination as BaseOrderProductAttributeCombination;

class OrderProductAttributeCombination extends BaseOrderProductAttributeCombination
{
}
