<?php
namespace Thelia\Model;

use Thelia\Model\Base\Profile as BaseProfile;
use Thelia\Model\Tools\ModelEventDispatcherTrait;

class Profile extends BaseProfile
{
    use ModelEventDispatcherTrait;
}
