<?php

namespace Thelia\Model;

use Thelia\Model\Base\CouponModule as BaseCouponModule;

class CouponModule extends BaseCouponModule
{
}
