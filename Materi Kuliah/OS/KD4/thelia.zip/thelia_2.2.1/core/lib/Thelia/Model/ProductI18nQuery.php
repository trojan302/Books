<?php

namespace Thelia\Model;

use Thelia\Model\Base\ProductI18nQuery as BaseProductI18nQuery;

/**
 * Skeleton subclass for performing query and update operations on the 'product_i18n' table.
 *
 *
 *
 * You should add additional methods to this class to meet the
 * application requirements.  This class will only be generated as
 * long as it does not already exist in the output directory.
 *
 */
class ProductI18nQuery extends BaseProductI18nQuery
{
}
// ProductI18nQuery
