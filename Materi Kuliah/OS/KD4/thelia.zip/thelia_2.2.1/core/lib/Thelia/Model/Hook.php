<?php

namespace Thelia\Model;

use Thelia\Model\Base\Hook as BaseHook;

class Hook extends BaseHook
{
}
