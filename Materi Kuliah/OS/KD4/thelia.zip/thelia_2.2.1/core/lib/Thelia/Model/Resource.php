<?php

namespace Thelia\Model;

use Thelia\Model\Base\Resource as BaseResource;

class Resource extends BaseResource
{
}
