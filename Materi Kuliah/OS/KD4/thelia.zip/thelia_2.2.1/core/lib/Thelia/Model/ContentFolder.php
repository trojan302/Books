<?php

namespace Thelia\Model;

use Thelia\Model\Base\ContentFolder as BaseContentFolder;

class ContentFolder extends BaseContentFolder
{
}
