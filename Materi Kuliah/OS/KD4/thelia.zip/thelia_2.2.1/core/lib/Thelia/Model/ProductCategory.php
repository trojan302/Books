<?php

namespace Thelia\Model;

use Thelia\Model\Base\ProductCategory as BaseProductCategory;

class ProductCategory extends BaseProductCategory
{
}
