<?php

namespace Thelia\Model;

use Thelia\Model\Base\ProductSaleElementsProductDocument as BaseProductSaleElementsProductDocument;

class ProductSaleElementsProductDocument extends BaseProductSaleElementsProductDocument
{
}
