<?php
/*************************************************************************************/
/*      This file is part of the Thelia package.                                     */
/*                                                                                   */
/*      Copyright (c) OpenStudio                                                     */
/*      email : dev@thelia.net                                                       */
/*      web : http://www.thelia.net                                                  */
/*                                                                                   */
/*      For the full copyright and license information, please view the LICENSE.txt  */
/*      file that was distributed with this source code.                             */
/*************************************************************************************/

namespace Thelia\Log;

use Thelia\Model\ConfigQuery;

class TlogDestinationConfig
{
    const TYPE_TEXTAREA = 1;
    const TYPE_TEXTFIELD = 2;

    protected $name;
    protected $title;
    protected $label;
    protected $default;
    protected $type;
    protected $value;

    public function __construct($name, $title, $label, $default, $type)
    {
        $this->name = $name;
        $this->title = $title;
        $this->label = $label;
        $this->default = $default;
        $this->type= $type;
        $this->value = ConfigQuery::read($this->name, $this->default);
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($title)
    {
        $this->title = $title;
    }

    public function getLabel()
    {
        return $this->label;
    }

    public function setLabel($label)
    {
        $this->label = $label;
    }

    public function getDefault()
    {
        return $this->default;
    }

    public function setDefault($default)
    {
        $this->default = $default;
    }

    public function getType()
    {
        return $this->type;
    }

    public function setType($type)
    {
        $this->type = $type;
    }

    public function getValue()
    {
        return $this->value;
    }

    public function setValue($value)
    {
        $this->value = $value;
    }
}
