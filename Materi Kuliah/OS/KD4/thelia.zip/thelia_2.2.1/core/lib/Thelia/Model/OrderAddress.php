<?php

namespace Thelia\Model;

use Thelia\Model\Base\OrderAddress as BaseOrderAddress;

class OrderAddress extends BaseOrderAddress
{
}
