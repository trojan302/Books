<?php

namespace Thelia\Model;

use Thelia\Model\Base\FolderVersion as BaseFolderVersion;

class FolderVersion extends BaseFolderVersion
{
}
