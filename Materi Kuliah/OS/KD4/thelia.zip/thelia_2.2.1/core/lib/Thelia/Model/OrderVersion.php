<?php

namespace Thelia\Model;

use Thelia\Model\Base\OrderVersion as BaseOrderVersion;

class OrderVersion extends BaseOrderVersion
{
}
