<?php

namespace Thelia\Model;

use Thelia\Model\Base\ModuleConfig as BaseModuleConfig;

class ModuleConfig extends BaseModuleConfig
{
}
