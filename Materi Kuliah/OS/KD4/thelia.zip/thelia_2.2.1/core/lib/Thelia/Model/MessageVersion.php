<?php

namespace Thelia\Model;

use Thelia\Model\Base\MessageVersion as BaseMessageVersion;

class MessageVersion extends BaseMessageVersion
{
}
