<?php

namespace Thelia\Model;

use Thelia\Model\Base\ContentVersion as BaseContentVersion;

class ContentVersion extends BaseContentVersion
{
}
