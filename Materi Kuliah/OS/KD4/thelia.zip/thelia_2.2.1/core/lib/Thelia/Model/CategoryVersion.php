<?php

namespace Thelia\Model;

use Thelia\Model\Base\CategoryVersion as BaseCategoryVersion;

class CategoryVersion extends BaseCategoryVersion
{
}
