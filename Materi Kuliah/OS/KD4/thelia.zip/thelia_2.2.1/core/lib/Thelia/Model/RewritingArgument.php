<?php

namespace Thelia\Model;

use Thelia\Model\Base\RewritingArgument as BaseRewritingArgument;

class RewritingArgument extends BaseRewritingArgument
{
}
