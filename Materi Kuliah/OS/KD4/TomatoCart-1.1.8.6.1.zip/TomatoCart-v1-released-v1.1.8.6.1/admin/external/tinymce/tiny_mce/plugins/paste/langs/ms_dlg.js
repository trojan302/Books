tinyMCE.addI18n('ms.paste_dlg',{
text_title:"Guna CTRL+V pada papan kekunci anda untuk Tempel teks ke dalam tetingkap.",
text_linebreaks:"Biarkan garisan pemisah",
word_title:"Guna CTRL+V pada papan kekunci anda untuk teks ke dalam tetingkap."
});